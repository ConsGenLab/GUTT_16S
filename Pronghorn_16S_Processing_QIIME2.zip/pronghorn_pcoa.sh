#!/bin/bash
#SBATCH -J Pronghorn_16S_PCOA
#SBATCH -o log.o%j 
#SBATCH --account=gutbiome
#SBATCH -N 1
#SBATCH -n 14
#SBATCH -t 1-00:00:00
#SBATCH --mail-type=END
#SBATCH --mail-type=BEGIN
#SBATCH --mail-type=FAIL
#SBATCH --mail-user=cbuchan3@uwyo.edu

# Ensure the temporary directory is in your scratch, so that big files don't take up too much space.
# Ensure that you call conda activate qiime2-2021.2 before you start. 

export TMPDIR=/gscratch/cbuchan3
module load qiime2/2021.4

# Create a 'shortcut' to the folder you're going to be working out of:
Pronghorn_16S=/project/gutbiome/cbuchan3/pronghorn
## Beta Diversity

qiime emperor plot \
--i-pcoa ${Pronghorn_16S}/core-metrics-results/unweighted_unifrac_pcoa_results.qza \
--m-metadata-file ${Pronghorn_16S}/pronghorn_metadata.tsv \
--o-visualization ${Pronghorn_16S}/core-metrics-results/unweighted-unifrac-emperor_text.qzv
