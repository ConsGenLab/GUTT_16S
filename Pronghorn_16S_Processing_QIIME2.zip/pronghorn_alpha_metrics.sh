#!/bin/bash
#SBATCH -J Pronghorn_16S_Alpha_Diversity
#SBATCH -o log.o%j 
#SBATCH --account=gutbiome
#SBATCH -N 1
#SBATCH -n 14
#SBATCH -t 1-00:00:00
#SBATCH --mail-type=END
#SBATCH --mail-type=BEGIN
#SBATCH --mail-type=FAIL
#SBATCH --mail-user=cbuchan3@uwyo.edu

# Ensure the temporary directory is in your scratch, so that big files don't take up too much space.
# Ensure that you call conda activate qiime2-2021.2 before you start. 

export TMPDIR=/gscratch/cbuchan3
module load qiime2/2021.4

# Create a 'shortcut' to the folder you're going to be working out of:
Pronghorn_16S=/project/gutbiome/cbuchan3/pronghorn


qiime diversity core-metrics-phylogenetic \
--i-table ${Pronghorn_16S}/filtered_table.qza \
--i-phylogeny ${Pronghorn_16S}/sepp-tree.qza \
--m-metadata-file ${Pronghorn_16S}/pronghorn_metadata.tsv \
--p-sampling-depth 5000 \
--output-dir ${Pronghorn_16S}/core-metrics-results

## Alpha Diversity

#Faith’s PD
qiime diversity alpha-group-significance --i-alpha-diversity ${Pronghorn_16S}/core-metrics-results/faith_pd_vector.qza --m-metadata-file ${Pronghorn_16S}/pronghorn_metadata.tsv --o-visualization ${Pronghorn_16S}/core-metrics-results/faith-pd-group-significance.qzv

#Eveness Metric
qiime diversity alpha-group-significance --i-alpha-diversity ${Pronghorn_16S}/core-metrics-results/evenness_vector.qza --m-metadata-file ${Pronghorn_16S}/pronghorn_metadata.tsv --o-visualization ${Pronghorn_16S}/core-metrics-results/evenness-group-significance.qzv
	
#Shannon’s Metric
qiime diversity alpha-group-significance --i-alpha-diversity ${Pronghorn_16S}/core-metrics-results/shannon_vector.qza --m-metadata-file ${Pronghorn_16S}/pronghorn_metadata.tsv --o-visualization ${Pronghorn_16S}/core-metrics-results/shannon_group-significance.qzv
